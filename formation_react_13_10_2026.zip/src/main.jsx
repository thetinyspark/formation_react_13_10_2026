import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';
import GameProvider from './contexts/GameProvider';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './store/store';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <GameProvider>
        <Provider store={store}>
          <App />
        </Provider>
      </GameProvider>
    </BrowserRouter>
  </React.StrictMode>
);
